/*
welcome use this file! 
Please visit kedei.taobao.com
qq310953417
vision 1.0 2014/12/20
*/
#ifndef 	_TP_CALIBRATION_H_
#define		_TP_CALIBRATION_H_

int xy[][4]=
{
	{0,0,25,25},
	{0,0,215,25},
	{0,0,215,295},
	{0,0,25,295},
	{0,0,120,160},
};


#endif